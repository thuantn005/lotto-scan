// scan_per_draw.cpp — Quet 1 dai seed CO DINH cho TAT CA cac ky trong CSV,
// GHI RA 1 FILE DUY NHAT (khong con tao 850 file rieng le nua).
//
// Thuat toan giu nguyen 100% tu scan_v2.cpp (da kiem chung khop voi du lieu mau):
//   ticket(seed, draw_id) = unrank_colex( splitmix64_mix(seed*M1 + draw_id*M2) mod C(35,5) )
//   special = splitmix64_mix(mixed) mod 12 + 1
//
// Neu file dau ra (OUT_FILE) da ton tai, chuong trinh se DOC lai cac ky da co,
// CHI QUET cac ky moi (chua co trong file), roi GOP ket qua vao cung 1 file
// (khong can flag rieng, luon tu dong "skip cac ky da xong").
//
// ENV:
//   CSV_PATH     - duong dan file CSV cac ky quay (mac dinh data/all.csv)
//   OUT_DIR      - thu muc chua file ket qua (mac dinh l1_merged)
//   OUT_NAME     - ten file ket qua (mac dinh: merged_seed{SEED_START}.json)
//   SEED_START   - diem bat dau dai seed (mac dinh 682305800400)
//   SEED_COUNT   - so seed can quet (mac dinh 1557775799; workflow model chinh dung 10000000000)
//                  DOI SEED_START/SEED_COUNT so voi file cu => tu dong quet lai TAT CA ky (khong tron dai)
//   NUM_THREADS  - so luong thread (mac dinh = so core)
//   FORCE_RESCAN - "1" = bo qua file cu, quet lai TAT CA tu dau (mac dinh "0")
//   LAST_N_DRAWS - > 0: chi quet N ky MOI NHAT theo draw_id, bo qua cac ky con lai
//                  (mac dinh 0 = quet toan bo CSV nhu truoc)

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>
#include <string>
#include <unordered_set>
#include <fstream>
#include <sstream>
#include <chrono>
#include <algorithm>
#include <filesystem>
#include <thread>
#include <unordered_map>
#include <mutex>
#include <atomic>

namespace fs = std::filesystem;
using u64 = uint64_t;

constexpr u64 M1 = 0x9E3779B97F4A7C15ULL;
constexpr u64 M2 = 0xD1B54A32D192ED03ULL;
constexpr u64 M3 = 0xBF58476D1CE4E5B9ULL;
constexpr u64 M4 = 0x94D049BB133111EBULL;
constexpr int64_t C = 324632;

static int64_t BINOM[36][6];
static std::vector<int64_t> RANK_TO_MASK;

void build_binom() {
    for (int n = 0; n <= 35; n++)
        for (int k = 0; k <= 5; k++) {
            if (k == 0) { BINOM[n][k] = 1; continue; }
            if (k > n) { BINOM[n][k] = 0; continue; }
            int64_t num = 1, den = 1;
            for (int i = 0; i < k; i++) { num *= (n - i); den *= (i + 1); }
            BINOM[n][k] = num / den;
        }
}
inline int64_t rank_mask_calc(int64_t r) {
    int64_t mask = 0, rem = r;
    for (int k = 5; k >= 1; k--) {
        int x = k - 1;
        while (BINOM[x + 1][k] <= rem) x++;
        mask |= (1LL << x); rem -= BINOM[x][k];
    }
    return mask;
}
void build_lut() { RANK_TO_MASK.resize(C); for (int64_t r=0;r<C;r++) RANK_TO_MASK[r]=rank_mask_calc(r); }

inline u64 mix64(u64 x) {
    x ^= x >> 30; x *= M3; x ^= x >> 27; x *= M4; x ^= x >> 31;
    return x;
}

struct Draw { u64 draw_id; std::string date; int64_t mask; int special; };
struct DrawResult { u64 draw_id; std::string date; std::vector<u64> seeds; };

std::string json_escape(const std::string& s) {
    std::string out;
    for (char c : s) { if (c=='"'||c=='\\') out+='\\'; out+=c; }
    return out;
}

std::vector<Draw> load_csv(const std::string& csv_path) {
    std::vector<Draw> draws;
    std::ifstream f(csv_path);
    if (!f) { fprintf(stderr, "Khong mo duoc %s\n", csv_path.c_str()); exit(1); }
    std::string line;
    std::getline(f, line);
    while (std::getline(f, line)) {
        std::vector<std::string> fields;
        std::string cur; bool in_quotes = false;
        for (size_t i = 0; i < line.size(); i++) {
            char c = line[i];
            if (c == '"') { if (in_quotes && i+1<line.size() && line[i+1]=='"') { cur+='"'; i++; } else in_quotes=!in_quotes; }
            else if (c == ',' && !in_quotes) { fields.push_back(cur); cur.clear(); }
            else cur += c;
        }
        fields.push_back(cur);
        if (fields.size() < 5) continue;
        u64 draw_id;
        try { draw_id = std::stoull(fields[1]); } catch (...) { continue; }
        std::string draw_date = fields.size() > 2 ? fields[2] : "";
        std::string rj = fields[4];
        auto extract_nums = [](const std::string& s, const std::string& key) -> std::vector<int> {
            std::vector<int> out;
            size_t p = s.find(key); if (p==std::string::npos) return out;
            p = s.find('[', p); size_t q = s.find(']', p);
            if (p==std::string::npos || q==std::string::npos) return out;
            std::string inner = s.substr(p+1, q-p-1);
            std::stringstream ss(inner); std::string tok;
            while (std::getline(ss, tok, ',')) { try { out.push_back(std::stoi(tok)); } catch (...) {} }
            return out;
        };
        std::vector<int> nums = extract_nums(rj, "\"numbers\"");
        std::vector<int> spv  = extract_nums(rj, "\"special_numbers\"");
        if (nums.size() != 5 || spv.empty()) continue;
        int64_t mask = 0;
        for (int nn : nums) mask |= (1LL << (nn-1));
        draws.push_back({draw_id, draw_date, mask, spv[0]});
    }
    std::sort(draws.begin(), draws.end(), [](const Draw&a, const Draw&b){return a.draw_id<b.draw_id;});
    return draws;
}

inline bool check_j1(u64 seed, const Draw& draw) {
    u64 combined = seed * M1 + draw.draw_id * M2;
    u64 mixed = mix64(combined);
    int64_t rank = (int64_t)(mixed % (u64)C);
    int64_t mask = RANK_TO_MASK[rank];
    u64 mixed2 = mix64(mixed);
    int sp = (int)(mixed2 % 12) + 1;
    return (mask == draw.mask) && (sp == draw.special);
}

// Doc file merged cu (neu co), tra ve danh sach DrawResult da co san
std::vector<DrawResult> load_existing_merged(const std::string& path, u64& out_seed_start, u64& out_seed_end) {
    std::vector<DrawResult> existing;
    std::ifstream f(path);
    if (!f) return existing;
    std::stringstream buf; buf << f.rdbuf();
    std::string content = buf.str();
    if (content.empty()) return existing;

    auto extract_u64_field = [&](const std::string& key) -> u64 {
        size_t p = content.find("\"" + key + "\":");
        if (p == std::string::npos) return 0;
        p += key.size() + 3;
        size_t q = content.find_first_of(",}", p);
        try { return std::stoull(content.substr(p, q-p)); } catch (...) { return 0; }
    };
    out_seed_start = extract_u64_field("seed_start");
    out_seed_end = extract_u64_field("seed_end");

    // Tim mang "draws":[ ... ] va parse tho tung object {draw_id,draw_date,found,seeds:[...]}
    size_t draws_pos = content.find("\"draws\":[");
    if (draws_pos == std::string::npos) return existing;
    size_t pos = draws_pos + 9;

    while (true) {
        size_t obj_start = content.find('{', pos);
        if (obj_start == std::string::npos) break;
        // Tim vi tri ket thuc object nay: tim "]}" gan nhat sau "seeds":[
        size_t seeds_key = content.find("\"seeds\":[", obj_start);
        if (seeds_key == std::string::npos) break;
        size_t seeds_arr_start = seeds_key + 9;
        size_t seeds_arr_end = content.find(']', seeds_arr_start);
        size_t obj_end = content.find('}', seeds_arr_end);
        if (obj_end == std::string::npos) break;

        std::string obj = content.substr(obj_start, obj_end - obj_start + 1);

        auto extract_field_str = [&](const std::string& key) -> std::string {
            size_t p = obj.find("\"" + key + "\":");
            if (p == std::string::npos) return "";
            p += key.size() + 3;
            if (obj[p] == '"') {
                size_t q = obj.find('"', p+1);
                return obj.substr(p+1, q-p-1);
            }
            size_t q = obj.find_first_of(",}", p);
            return obj.substr(p, q-p);
        };

        DrawResult dr;
        try { dr.draw_id = std::stoull(extract_field_str("draw_id")); } catch (...) { pos = obj_end+1; continue; }
        dr.date = extract_field_str("draw_date");

        std::string inner = content.substr(seeds_arr_start, seeds_arr_end - seeds_arr_start);
        if (!inner.empty()) {
            std::stringstream ss(inner); std::string tok;
            while (std::getline(ss, tok, ',')) {
                try { dr.seeds.push_back(std::stoull(tok)); } catch (...) {}
            }
        }
        existing.push_back(std::move(dr));
        pos = obj_end + 1;

        // Kiem tra da het mang draws chua (gap "]" dong mang truoc "}" dong object ngoai)
        size_t next_brace = content.find_first_not_of(" \t\n,", pos);
        if (next_brace != std::string::npos && content[next_brace] == ']') break;
    }
    return existing;
}

// ---------------------------------------------------------------------
// CHECKPOINT: cho phep RESUME neu job bi ngat giua chung (het timeout-
// minutes cua GitHub Actions, runner mat ket noi, v.v.) ma KHONG PHAI
// quet lai TU DAU dai seed - job scan nay co the chay toi 370 phut/lan,
// mat giua chung se lang phi hang gio CPU neu khong co checkpoint.
//
// MOI CHECKPOINT_INTERVAL_SEC giay (mac dinh 300 = 5 phut), ghi lai VI
// TRI DA QUET CUA TUNG THREAD **VA TOAN BO SEED TRUNG DA TIM THAY**
// ("hits": [draw_id,seed,draw_id,seed,...]). Moi thread chi khoa mutex
// rieng cua no khi push 1 seed trung (rat hiem, ~1/3,9 trieu luot kiem
// tra) va khi monitor chup snapshot, nen khong anh huong toc do. Snapshot
// luon nhat quan: hit duoc push TRUOC khi tien do khoi chua no duoc ghi,
// nen resume khong bao gio mat seed; khoi dang quet do co the bi quet lai
// -> seed trung bi lap, da khu bang sort+unique luc gop ket qua.
//
// Checkpoint CHI duoc dung lai neu KHOP HOAN TOAN ca seed_start,
// seed_count, num_threads VA danh sach draw_id dang quet (neu bat ky yeu
// to nao khac di - vi du co ky moi phat sinh giua luc ngat va luc chay
// lai - checkpoint cu bi BO QUA, quet lai tu dau, AN TOAN nhung cham
// hon, KHONG BAO GIO sai ket qua vi luon quet DU dai seed duoc giao).
// ---------------------------------------------------------------------

struct Checkpoint {
    bool valid = false;
    u64 seed_start = 0, seed_count = 0;
    unsigned int num_threads = 0;
    std::vector<u64> draw_ids;
    std::vector<u64> progress; // so seed DA quet (offset) trong dai rieng cua tung thread
    std::vector<u64> hits;     // phang: draw_id, seed, draw_id, seed, ... (seed trung da tim thay)
};

std::vector<u64> parse_u64_array(const std::string& s) {
    std::vector<u64> out;
    std::stringstream ss(s); std::string tok;
    while (std::getline(ss, tok, ',')) {
        size_t a = tok.find_first_not_of(" \t\n\r");
        if (a == std::string::npos) continue;
        size_t b = tok.find_last_not_of(" \t\n\r");
        try { out.push_back(std::stoull(tok.substr(a, b - a + 1))); } catch (...) {}
    }
    return out;
}

Checkpoint load_checkpoint(const std::string& path) {
    Checkpoint ck;
    std::ifstream f(path);
    if (!f) return ck;
    std::stringstream buf; buf << f.rdbuf();
    std::string content = buf.str();
    if (content.empty()) return ck;

    auto extract_field = [&](const std::string& key) -> std::string {
        size_t p = content.find("\"" + key + "\":");
        if (p == std::string::npos) return "";
        p += key.size() + 3;
        if (p < content.size() && content[p] == '[') {
            size_t q = content.find(']', p);
            if (q == std::string::npos) return "";
            return content.substr(p + 1, q - p - 1);
        }
        size_t q = content.find_first_of(",}", p);
        return content.substr(p, q - p);
    };

    try {
        ck.seed_start = std::stoull(extract_field("seed_start"));
        ck.seed_count = std::stoull(extract_field("seed_count"));
        ck.num_threads = (unsigned int)std::stoul(extract_field("num_threads"));
    } catch (...) { return ck; }
    ck.draw_ids = parse_u64_array(extract_field("draw_ids"));
    ck.progress = parse_u64_array(extract_field("progress"));
    ck.hits = parse_u64_array(extract_field("hits"));
    ck.valid = (ck.hits.size() % 2 == 0); // le -> checkpoint hong, bo qua
    return ck;
}

// Ghi ra file .tmp roi RENAME (rename cung filesystem la atomic tren
// Linux) - tranh checkpoint bi HONG (ghi do dang) neu runner bi kill
// dung luc dang ghi, luc do file checkpoint CU (con nguyen ven) van con.
void save_checkpoint(const std::string& path, u64 seed_start, u64 seed_count,
                      unsigned int num_threads, const std::vector<u64>& draw_ids,
                      const std::vector<u64>& progress, const std::vector<u64>& hits) {
    std::string tmp_path = path + ".tmp";
    FILE* f = fopen(tmp_path.c_str(), "w");
    if (!f) return;
    fprintf(f, "{\"seed_start\":%llu,\"seed_count\":%llu,\"num_threads\":%u,\"draw_ids\":[",
            (unsigned long long)seed_start, (unsigned long long)seed_count, num_threads);
    for (size_t i = 0; i < draw_ids.size(); i++) {
        if (i) fprintf(f, ",");
        fprintf(f, "%llu", (unsigned long long)draw_ids[i]);
    }
    fprintf(f, "],\"progress\":[");
    for (size_t i = 0; i < progress.size(); i++) {
        if (i) fprintf(f, ",");
        fprintf(f, "%llu", (unsigned long long)progress[i]);
    }
    fprintf(f, "],\"hits\":[");
    for (size_t i = 0; i < hits.size(); i++) {
        if (i) fprintf(f, ",");
        fprintf(f, "%llu", (unsigned long long)hits[i]);
    }
    fprintf(f, "]}");
    fclose(f);
    std::error_code ec;
    fs::rename(tmp_path, path, ec);
    if (ec) fprintf(stderr, "Canh bao: khong rename duoc checkpoint (%s)\n", ec.message().c_str());
}

int main() {
    build_binom();

    auto getenv_str = [](const char* name, const char* def) -> std::string {
        const char* v = std::getenv(name); return v ? std::string(v) : std::string(def);
    };
    auto getenv_u64 = [&](const char* name, u64 def) -> u64 {
        std::string s = getenv_str(name, ""); return s.empty() ? def : std::stoull(s);
    };

    std::string csv_path = getenv_str("CSV_PATH", "data/all.csv");
    std::string out_dir  = getenv_str("OUT_DIR", "l1_merged");
    u64 seed_start = getenv_u64("SEED_START", 682305800400ULL);
    u64 seed_count = getenv_u64("SEED_COUNT", 1557775799ULL);
    u64 seed_end = seed_start + seed_count - 1;
    bool force_rescan = getenv_str("FORCE_RESCAN", "0") == "1";
    // LAST_N_DRAWS > 0: chi quet N ky MOI NHAT (theo draw_id) thay vi toan bo CSV.
    // Dung cho cac lan quet "1 lan" pham vi hep (vd 10/20 ky gan nhat) tren dai seed lon.
    u64 last_n_draws = getenv_u64("LAST_N_DRAWS", 0ULL);

    std::string out_name = getenv_str("OUT_NAME", "");
    if (out_name.empty()) out_name = "merged_seed" + std::to_string(seed_start) + ".json";
    std::string out_path = out_dir + "/" + out_name;

    std::vector<Draw> draws_all = load_csv(csv_path);
    if (last_n_draws > 0 && draws_all.size() > last_n_draws) {
        // draws_all da duoc sap xep tang dan theo draw_id (xem load_csv) -> lay N phan tu cuoi
        draws_all.erase(draws_all.begin(), draws_all.end() - (long)last_n_draws);
        fprintf(stderr, "LAST_N_DRAWS=%llu -> chi giu %zu ky gan nhat (draw_id %llu..%llu)\n",
                (unsigned long long)last_n_draws, draws_all.size(),
                (unsigned long long)draws_all.front().draw_id,
                (unsigned long long)draws_all.back().draw_id);
    }
    int n_all = (int)draws_all.size();
    fprintf(stderr, "Loaded %d ky can quet. Dai seed: %llu -> %llu (%llu seed)\n",
            n_all, (unsigned long long)seed_start, (unsigned long long)seed_end, (unsigned long long)seed_count);
    if (n_all == 0) { fprintf(stderr, "Khong co du lieu\n"); return 1; }

    // Doc file merged cu (neu co va khong force_rescan)
    std::vector<DrawResult> existing_results;
    if (!force_rescan) {
        u64 old_start=0, old_end=0;
        existing_results = load_existing_merged(out_path, old_start, old_end);
        // DAI SEED DOI (vd tang SEED_COUNT 1,56 ty -> 10 ty): cac ky cu chi duoc quet tren dai CU,
        // khong the "quet tiep chi ky moi" - phai quet lai TAT CA ky tren dai moi (an toan, khong tron dai).
        if (!existing_results.empty() && (old_start != seed_start || old_end != seed_end)) {
            fprintf(stderr, "Dai seed trong file cu (%llu..%llu) KHAC dai hien tai (%llu..%llu) -> "
                            "BO file cu, quet lai TAT CA ky tren dai moi\n",
                    (unsigned long long)old_start, (unsigned long long)old_end,
                    (unsigned long long)seed_start, (unsigned long long)seed_end);
            existing_results.clear();
        }
        if (!existing_results.empty()) {
            fprintf(stderr, "Doc duoc file cu %s: %zu ky da co san\n", out_path.c_str(), existing_results.size());
        }
    }

    std::unordered_set<u64> existing_draw_ids;
    for (auto& dr : existing_results) existing_draw_ids.insert(dr.draw_id);

    std::vector<Draw> draws; // chi cac ky MOI can quet
    for (auto& d : draws_all) {
        if (existing_draw_ids.find(d.draw_id) == existing_draw_ids.end()) draws.push_back(d);
    }

    int n = (int)draws.size();
    fprintf(stderr, "%d/%d ky da co san, con %d ky moi can quet\n",
            n_all - n, n_all, n);

    if (n == 0) {
        fprintf(stderr, "Khong co ky moi can quet. Da xong (file van giu nguyen).\n");
        printf("TOTAL_FILES=1\n");
        printf("NEW_DRAWS=0\n");
        printf("TOTAL_FOUND=0\n");
        return 0;
    }

    unsigned int num_threads = std::thread::hardware_concurrency();
    if (num_threads == 0) num_threads = 4;
    {
        std::string nt = getenv_str("NUM_THREADS", "");
        if (!nt.empty()) num_threads = (unsigned int)std::stoul(nt);
    }
    if (num_threads < 1) num_threads = 1;

    fs::create_directories(out_dir);

    auto t0 = std::chrono::steady_clock::now();

    std::vector<u64> draw_ids;
    draw_ids.reserve(n);
    for (auto& d : draws) draw_ids.push_back(d.draw_id);

    std::string checkpoint_path = out_path + ".ckpt.json";
    double checkpoint_interval_sec = (double)getenv_u64("CHECKPOINT_INTERVAL_SEC", 300ULL);
    bool resume_enabled = getenv_str("RESUME_FROM_CHECKPOINT", "1") != "0";

    bool use_checkpoint = false;
    std::vector<u64> resume_offsets(num_threads, 0);
    if (resume_enabled) {
        Checkpoint ck = load_checkpoint(checkpoint_path);
        if (ck.valid && ck.seed_start == seed_start && ck.seed_count == seed_count &&
            ck.num_threads == num_threads && ck.draw_ids == draw_ids &&
            ck.progress.size() == num_threads) {
            use_checkpoint = true;
            resume_offsets = ck.progress;
            u64 total_resumed = 0;
            for (u64 v : resume_offsets) total_resumed += v;
            fprintf(stderr, "Tim thay checkpoint KHOP ngu canh hien tai - RESUME (da quet ~%llu/%llu seed truoc do)\n",
                    (unsigned long long)total_resumed, (unsigned long long)seed_count);
        } else if (ck.valid) {
            fprintf(stderr, "Co checkpoint cu nhung KHONG khop ngu canh hien tai (seed_start/seed_count/"
                             "num_threads/danh sach ky moi da doi) - BO QUA, quet lai tu dau (an toan).\n");
        }
    }

    std::vector<std::vector<std::vector<u64>>> thread_results(
        num_threads, std::vector<std::vector<u64>>(n));

    std::vector<std::mutex> thread_mtx(num_threads);
    if (use_checkpoint) {
        std::unordered_map<u64,int> idx; // draw_id -> chi so
        for (int i = 0; i < n; i++) idx[draw_ids[i]] = i;
        Checkpoint ck = load_checkpoint(checkpoint_path);
        size_t restored = 0;
        for (size_t i = 0; i + 1 < ck.hits.size(); i += 2) {
            auto it = idx.find(ck.hits[i]);
            if (it != idx.end()) { thread_results[0][it->second].push_back(ck.hits[i + 1]); restored++; }
        }
        fprintf(stderr, "  khoi phuc %zu seed trung tu checkpoint\n", restored);
    }

    std::atomic<u64> checked_total{0};
    std::vector<std::atomic<u64>> thread_progress(num_threads);
    for (unsigned int t = 0; t < num_threads; t++) thread_progress[t].store(0, std::memory_order_relaxed);

    u64 chunk = seed_count / num_threads;
    u64 remainder = seed_count % num_threads;

    // TOI UU (2.3x): so sanh RANK thay vi tra LUT 2,6MB; draw_id*M2 tinh san;
    // seed*M1 cong don; xu ly 4 seed/lan de CPU chay song song (ILP);
    // mix64 lan 2 (special) chi tinh khi rank da trung (xac suat 1/324632).
    std::vector<u64> doff(n), dsp(n), drank(n);
    for (int i = 0; i < n; i++) {
        doff[i] = draws[i].draw_id * M2;
        dsp[i] = (u64)draws[i].special;
        int k = 1; int64_t r = 0;
        for (int x = 0; x < 35; x++) if ((draws[i].mask >> x) & 1) { r += BINOM[x][k]; k++; }
        drank[i] = (u64)r;
    }
    auto worker = [&](unsigned int tid, u64 range_start, u64 range_count, u64 already_progress) {
        auto& local = thread_results[tid];
        u64 local_checked = 0;
        thread_progress[tid].store(already_progress, std::memory_order_relaxed);
        const u64 range_end = range_start + range_count;
        u64 seed = range_start;
        u64 base = seed * M1;
        auto hit = [&](u64 mixed, int di, u64 sd) {
            if ((mix64(mixed) % 12) + 1 == dsp[di]) { std::lock_guard<std::mutex> lk(thread_mtx[tid]); local[di].push_back(sd); }
        };
        for (; seed + 4 <= range_end; seed += 4, base += 4 * M1) {
            for (int di = 0; di < n; di++) {
                const u64 d = doff[di], r = drank[di];
                u64 m0 = mix64(base + d), m1 = mix64(base + M1 + d);
                u64 m2 = mix64(base + 2 * M1 + d), m3 = mix64(base + 3 * M1 + d);
                if (m0 % (u64)C == r) hit(m0, di, seed);
                if (m1 % (u64)C == r) hit(m1, di, seed + 1);
                if (m2 % (u64)C == r) hit(m2, di, seed + 2);
                if (m3 % (u64)C == r) hit(m3, di, seed + 3);
            }
            local_checked += 4;
            thread_progress[tid].store(already_progress + local_checked, std::memory_order_relaxed);
            if ((local_checked & 0xFFFFF) == 0) checked_total.fetch_add(0x100000, std::memory_order_relaxed);
        }
        for (; seed < range_end; seed++, base += M1) {
            for (int di = 0; di < n; di++) {
                u64 m = mix64(base + doff[di]);
                if (m % (u64)C == drank[di]) hit(m, di, seed);
            }
            local_checked++;
            thread_progress[tid].store(already_progress + local_checked, std::memory_order_relaxed);
            if ((local_checked & 0xFFFFF) == 0) checked_total.fetch_add(0x100000, std::memory_order_relaxed);
        }
        checked_total.fetch_add(local_checked & 0xFFFFF, std::memory_order_relaxed);
    };

    std::vector<std::thread> threads;
    u64 offset = 0;
    for (unsigned int t = 0; t < num_threads; t++) {
        u64 this_count = chunk + (t < remainder ? 1 : 0);
        u64 already = use_checkpoint ? std::min(resume_offsets[t], this_count) : 0;
        threads.emplace_back(worker, t, seed_start + offset + already, this_count - already, already);
        offset += this_count;
    }

    std::atomic<bool> done{false};
    std::thread monitor([&]() {
        auto last_log = t0;
        auto last_checkpoint = t0;
        while (!done.load()) {
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration<double>(now - last_log).count() >= 15.0) {
                double elapsed = std::chrono::duration<double>(now - t0).count();
                u64 c = checked_total.load(std::memory_order_relaxed);
                fprintf(stderr, "  checked~=%llu/%llu seed (%.0f/s, %u threads)\n",
                        (unsigned long long)c, (unsigned long long)seed_count,
                        elapsed > 0 ? c/elapsed : 0.0, num_threads);
                last_log = now;
            }
            if (std::chrono::duration<double>(now - last_checkpoint).count() >= checkpoint_interval_sec) {
                std::vector<u64> snapshot(num_threads), hitsnap;
                for (unsigned int t = 0; t < num_threads; t++) {
                    std::lock_guard<std::mutex> lk(thread_mtx[t]);
                    snapshot[t] = thread_progress[t].load(std::memory_order_relaxed);
                    for (int di = 0; di < n; di++)
                        for (u64 sd : thread_results[t][di]) { hitsnap.push_back(draw_ids[di]); hitsnap.push_back(sd); }
                }
                save_checkpoint(checkpoint_path, seed_start, seed_count, num_threads, draw_ids, snapshot, hitsnap);
                fprintf(stderr, "  [checkpoint] da luu tien do vao %s\n", checkpoint_path.c_str());
                last_checkpoint = now;
            }
        }
    });

    for (auto& th : threads) th.join();
    done.store(true);
    monitor.join();

    fprintf(stderr, "Quet xong %d ky moi, dang gop vao file...\n", n);

    u64 total_found_new = 0;
    std::vector<DrawResult> new_results;
    for (int di = 0; di < n; di++) {
        std::vector<u64> seeds_for_draw;
        for (unsigned int t = 0; t < num_threads; t++) {
            auto& v = thread_results[t][di];
            seeds_for_draw.insert(seeds_for_draw.end(), v.begin(), v.end());
        }
        std::sort(seeds_for_draw.begin(), seeds_for_draw.end());
        seeds_for_draw.erase(std::unique(seeds_for_draw.begin(), seeds_for_draw.end()), seeds_for_draw.end());
        total_found_new += seeds_for_draw.size();

        DrawResult dr;
        dr.draw_id = draws[di].draw_id;
        dr.date = draws[di].date;
        dr.seeds = std::move(seeds_for_draw);
        new_results.push_back(std::move(dr));
    }

    // Gop existing + new, sap xep theo draw_id
    std::vector<DrawResult> all_results = existing_results;
    for (auto& dr : new_results) all_results.push_back(std::move(dr));

    // QUAN TRONG - PRUNE ky cu ra khoi cua so: neu dang dung LAST_N_DRAWS
    // (cua so truot), existing_results co the con giu lai nhung ky DA
    // ROI RA NGOAI cua so hien tai (vd LAST_N_DRAWS=500, ky moi toi thi
    // ky cach day 501+ ky phai bi loai). Truoc day thieu buoc nay nen
    // phai dung FORCE_RESCAN=1 de tranh file phinh to vo han; gio prune
    // dung thi co the AN TOAN bo FORCE_RESCAN, chi quet ky MOI moi lan.
    if (last_n_draws > 0) {
        size_t before = all_results.size();
        std::unordered_set<u64> window_draw_ids;
        window_draw_ids.reserve(draws_all.size());
        for (auto& d : draws_all) window_draw_ids.insert(d.draw_id);

        std::vector<DrawResult> pruned;
        pruned.reserve(window_draw_ids.size());
        for (auto& dr : all_results) {
            if (window_draw_ids.count(dr.draw_id)) pruned.push_back(std::move(dr));
        }
        if (pruned.size() != before) {
            fprintf(stderr, "Prune cua so: bo %zu ky da roi ra ngoai LAST_N_DRAWS=%llu "
                             "(con lai %zu ky trong cua so)\n",
                    before - pruned.size(), (unsigned long long)last_n_draws, pruned.size());
        }
        all_results = std::move(pruned);
    }

    std::sort(all_results.begin(), all_results.end(),
              [](const DrawResult&a, const DrawResult&b){ return a.draw_id < b.draw_id; });

    u64 total_found_all = 0;
    for (auto& dr : all_results) total_found_all += dr.seeds.size();

    // Ghi ra 1 file DUY NHAT
    FILE* f = fopen(out_path.c_str(), "w");
    fprintf(f, "{\"seed_start\":%llu,\"seed_end\":%llu,\"total_draws\":%zu,\"total_found\":%llu,\"draws\":[",
            (unsigned long long)seed_start, (unsigned long long)seed_end,
            all_results.size(), (unsigned long long)total_found_all);
    for (size_t i = 0; i < all_results.size(); i++) {
        if (i) fprintf(f, ",");
        auto& dr = all_results[i];
        fprintf(f, "{\"draw_id\":%llu,\"draw_date\":\"%s\",\"found\":%zu,\"seeds\":[",
                (unsigned long long)dr.draw_id, json_escape(dr.date).c_str(), dr.seeds.size());
        for (size_t j = 0; j < dr.seeds.size(); j++) {
            if (j) fprintf(f, ",");
            fprintf(f, "%llu", (unsigned long long)dr.seeds[j]);
        }
        fprintf(f, "]}");
    }
    fprintf(f, "]}");
    fclose(f);

    // Quet da xong hoan toan cho dai seed + danh sach ky nay - checkpoint
    // khong con can thiet nua, xoa de tranh nham lan/tich luy file rac.
    std::remove(checkpoint_path.c_str());

    auto t1 = std::chrono::steady_clock::now();
    double elapsed = std::chrono::duration<double>(t1-t0).count();
    fprintf(stderr, "\nXong: ghi vao %s (%zu ky tong cong, %d ky moi quet lan nay, tong %llu luot trung J1), %.0fs (%u threads)\n",
            out_path.c_str(), all_results.size(), n, (unsigned long long)total_found_all, elapsed, num_threads);
    printf("TOTAL_FILES=1\n");
    printf("NEW_DRAWS=%d\n", n);
    printf("TOTAL_FOUND=%llu\n", (unsigned long long)total_found_all);
    printf("OUT_PATH=%s\n", out_path.c_str());

    return 0;
}
